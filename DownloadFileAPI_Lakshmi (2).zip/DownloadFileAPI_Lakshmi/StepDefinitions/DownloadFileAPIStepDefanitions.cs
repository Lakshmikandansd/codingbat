﻿using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestSharp;
using TechTalk.SpecFlow;
using NUnit.Framework;
using Newtonsoft.Json.Linq;

namespace DownloadFileAPI_Lakshmi.StepDefinitions
{

    [Binding]
   



        public class ApiSteps
        {
            private RestClient _client;
            private RestRequest _request;
            private RestResponse _response;

            [Given(@"I send a GET request to ""([^""]*)""")]
            public void GivenISendAGETRequestTo(string url)
            {
                _client = new RestClient(url);
                _request = new RestRequest(Method.GET);
            }

            [Then(@"I should receive a response with status code ""(.*)""")]
            public void ThenIShouldReceiveAResponseWithStatusCode(int expectedStatusCode)
            {
                _response = _client.Execute(_request);

                Assert.AreEqual(expectedStatusCode, (int)_response.StatusCode);
               
            }

            [Then(@"the response should contain user details")]
            public void ThenTheResponseShouldContainUserDetails()
            {
                Assert.IsNotNull(_response.Content);

                var responseJson = JObject.Parse(_response.Content);
                Assert.AreEqual("TestApp.zip", responseJson["productBuild.filename"].ToString());
            }
        }
    }


