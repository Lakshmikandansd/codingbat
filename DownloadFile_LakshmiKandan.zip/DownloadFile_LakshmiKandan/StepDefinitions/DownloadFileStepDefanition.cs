﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.IO;
using TechTalk.SpecFlow;
using NUnit.Framework;


namespace DownloadFile_LakshmiKandan.StepDefinitions
{
    [Binding]
    public class DownloadFileStepDefanition
    {
        private IWebDriver driver;
        int numberOfFilesDownloaded = 0;
        string[] FilesName;
        [Given(@"I am on the webpage to download a file")]
        public void GivenIAmOnTheWebpageToDownloadAFile()
        {
            // Set Chrome options for downloading without showing the dialog
            var options = new ChromeOptions();
            string downloadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Downloads");

            // Set the download location in Chrome
            options.AddUserProfilePreference("download.default_directory", downloadDirectory);
            options.AddUserProfilePreference("profile.default_content_settings.popups", 0);
            driver = new ChromeDriver(options);

            // Navigate to the webpage where the download link exists
            driver.Navigate().GoToUrl("https://orbiter-for-testing.azurewebsites.net/products/testApp?isInternal=false");
        }

        [When(@"I click the download link")]
        public void WhenIClickTheDownloadLink()
        {
            // Find the download link by its CSS selector or XPath
            var downloadLink = driver.FindElements(By.XPath("//a[contains(@href, 'zip')]")); 
            foreach(var downloadlink in downloadLink)
            {
                downloadlink.Click();
                numberOfFilesDownloaded++;
                FilesName[numberOfFilesDownloaded]= downloadlink.Text;
            }
        }

        [Then(@"the file should be downloaded successfully")]
        public void ThenTheFileShouldBeDownloadedSuccessfully()
        {
            // Wait for the file to be downloaded (this can vary depending on the file size, etc.)
            string downloadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Downloads");
            var files = Directory.GetFiles(downloadDirectory);

            // Assert that a file exists in the directory
            //Assert.IsTrue(files.Length > numberOfFilesDownloaded, "No files were downloaded.");

            // Optionally, check for the specific file name or extension
            foreach (var fileName in FilesName)
            {
                string downloadedFile = Path.Combine(downloadDirectory, fileName);
                //Assert.IsTrue(File.Exists(downloadedFile), "Downloaded file was not found.");
            }
           
        }

        [AfterScenario]
        public void CleanUp()
        {
            
            driver.Quit();
        }

    }
}
